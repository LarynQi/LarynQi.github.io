### Discussion 13 - Review Potpourri and SQL ###

################################
###   Environment Diagrams   ###
################################

# Q3 - boo
ghost = [1, 0,[3], 1]
def boo(spooky):
    ghost.append(spooky.append(ghost))
    spooky = spooky[ghost[2][1][1]]
    ghost[:].extend([spooky])
    spooky = [spooky] + [ghost[spooky - 1].pop()]
    ghost.remove(ghost.remove(1))
    spooky += ["Happy Halloween!"]
    return spooky
pumpkin = boo(ghost[2])

#####################
###   Recursion   ###
#####################

# Q4.1a - positionizer
def positionizer(n):
    """
    >>> positionizer(12)
    10
    >>> positionizer(23)
    20
    >>> positionizer(12345)
    12300
    """
    def helper(n, pos):
        if _____________________________________:
            return ________________________________
        rest = __________________________________
        if n % 10 == pos:
            return rest + _________________________
        else:
            return rest + _________________________
    return helper(______________, ______________)

# Q4.1b - max-positionizer
def max_positionizer(k, lst):
    """
    >>> max_positionizer(2, [1, 2, 3]) # positionized version of 12, 13, 23 are 10, 10, 20
    23
    >>> max_positionizer(3, [2, 5, 3, 1])
    251
    """
    def make_nums(k,lst):
        if ________________________________:
            return _______________________________
        elif ______________________________:
            return []
        a = [_____________________________ \
                for rest in __________________________]
        b = _______________________________________
        return a + b
    return _______(make_nums(____, ____), ____________)

###############
###   OOP   ###
###############

# Q5.1 - food
class Food:
    """
    >>> lettuce.can_eat()
    ________________________________
    >>> my_salad.can_eat()
    ________________________________
    >>> my_salad.mix_ingredients(); my_salad.name
    ________________________________
    ________________________________
    """
    def __init__(self, name, spoiled = False):
        self.name = name
        self.num_days = 0
        self.spoiled = spoiled
    def can_eat(self):
        self.num_days += 1
        if self.num_days >= 3:
            self.spoiled = True
            print("Oh no! Your food is spoiled!")
        return not self.spoiled

    def mix_food(self, other_food):
        self.num_days = self.num_days + other_food.num_days
        self.name += " " + other_food.name
        self.spoiled = self.spoiled and other_food.spoiled

class Salad(Food):
    def __init__(self, ingredients):
        super().__init__("salad", False)
        self.ingredients = ingredients
    def add_ingredients(self, ingredient):
        self.ingredients.append(ingredient)
        print(ingredient.name + " has been added")
    def mix_ingredients(self):
        for ingredient in self.ingredients:
            self.mix_food(ingredient)
        print("Your salad has been mixed.")

lettuce = Food("lettuce")
tomatoes = Food("tomatoes")
chicken = Food("chicken")
ingredients = [lettuce, tomatoes]
my_salad = Salad(ingredients)

#################
###   Trees   ###
#################

def total_weight(t):
    """
    Return the total weight of a tree, i.e. the sum of all its
    labels.
    >>> total_weight(Tree(1, [Tree(2), Tree(3,[Tree(4)])]))
    10
    """
    weight = t.label + sum([total_weight(branch) for branch in t.branches])
    return weight

# Q6.1 - equally-weighted
def equally_weighted(t):
    """
    Return whether a tree is equally weighted.
    >>> equally_weighted(Tree(1))
    True
    >>> equally_weighted(Tree(1,[Tree(2), Tree(1, [Tree(1)])]))
    True
    >>> equally_weighted(Tree(0, [Tree(3), Tree(2, [Tree(3)])]))
    False
    """
    _______________________ = [_________________________]
    for _______________ in _____________________________:
        if _____________________________:
            return ______________________________________
    return __________________________________________

# Q6.2 - num-eq-weight
def num_eq_weight(t):
    """
    Return the number of equally weighted subtrees of t. Note
    that t is considered a subtree of itself.
    >>> num_eq_weight(Tree(1, [Tree(4), Tree(3,[Tree(1)])]))
    4
    >>> num_eq_weight(Tree(1, [Tree(9), Tree(1, [Tree(4), Tree(3,[Tree(1)])])]))
    6
    >>> num_eq_weight(Tree(1, [Tree(8, [Tree(1)]), Tree(1, [Tree(4), Tree(3,[Tree(1)])])]))
    7
    """
    val = ______________________________________________
    if ______________________________________:
        return ___________________________________________
    else:
        return val

######################
###   Generators   ###
######################

# Q7.1 - root-to-leaf
def root_to_leaf(t):
    """
    >>> list(root_to_leaf(Tree(3, [Tree(5), Tree(4)])))
    [[3, 5], [3, 4]]
    >>> list(root_to_leaf(Tree(5, [Tree(2, [Tree(7), Tree(8)]), Tree(5, [Tree(6)])])))
    [[5, 5, 6]]
    """
    "*** UNCOMMENT SKELETON ***"
    """
    if ____________________:
        _________________________
    for _________________________:
        if __________________________:
            for __________________________:
                    ______________________________
    """

# Q7.2 - subpaths
def subpaths(t):
    """
    >>> sorted(list(subpaths(Tree(3, [Tree(4), Tree(3), Tree(2)]))), key=lambda p: sum(p))
    [[2], [3], [4], [3, 3], [3, 4]]
    """
    yield from _______________________
    for b in t.branches:
        ______________________________

### Reference Code for Trees ###

class Tree:
    """
    >>> t = Tree(3, [Tree(2, [Tree(5)]), Tree(4)])
    >>> t.label
    3
    >>> t.branches[0].label
    2
    >>> t.branches[1].is_leaf()
    True
    """
    def __init__(self, label, branches=[]):
        for b in branches:
            assert isinstance(b, Tree)
        self.label = label
        self.branches = list(branches)
    def __repr__(self):
        if self.branches:
            return 'Tree({0}, {1})'.format(self.label, repr(self.branches))
        else:
            return 'Tree({0})'.format(repr(self.label))
    def is_leaf(self):
        return not self.branches
    def __str__(self):
        def print_tree(t, indent=0):
            tree_str = ' ' * (4 * indent) + str(t.label) + "\n"
            for b in t.branches:
                tree_str += print_tree(b, indent + 1)
            return tree_str
        return print_tree(self).rstrip()