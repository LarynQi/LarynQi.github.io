"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q regex`
"""


### Discussion 15 - Final Review Part 2: Scheme and Regex ###


##########################
###   Regex Practice   ###
##########################


import re

# Q5.1 - regex
def linear_functions(eq_str):
    """
    Given the equation in the form of 'mx + b', returns a
    tuple of m and b values.
    >>> linear_functions("1x+0")
    [('1', '0')]
    >>> linear_functions("100y+44")
    [('100', '44')]
    >>> linear_functions("99.9z+23")
    [('99.9', '23')]
    >>> linear_functions("55t+0.4")
    [('55', '0.4')]
    """
    return re.findall(r'(\d*\.?\d+)\w\+?(\d*\.?\d+)', eq_str)
