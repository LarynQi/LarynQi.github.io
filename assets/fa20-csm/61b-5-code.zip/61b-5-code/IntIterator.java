interface IntIterator{
    boolean hasNext();
    int next();
}